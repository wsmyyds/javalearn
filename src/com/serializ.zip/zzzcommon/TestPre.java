package serializ.zzzcommon;

import java.io.Serializable;

/**
 * @program: code
 * @description:
 * @author:
 * @create:
 **/
public class TestPre implements Serializable {

    public int pre = 6;
}
